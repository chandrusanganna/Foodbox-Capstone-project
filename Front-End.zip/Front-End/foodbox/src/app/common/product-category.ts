export class ProductCategory {
    id: number;
    cuisine_name: string;
}
